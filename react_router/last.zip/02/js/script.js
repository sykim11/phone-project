var Page = (function($){
	
	var nav = function(){ 
		
		var index = $(this).index(); // 0 ~ 5
		
		$('.wrap').find('div').eq(index).show();
		$('.wrap').children().eq(index).siblings().hide();
		
		$(this).addClass('active');
		$(this).siblings().removeClass('active');
	};
	
	return  {
		
		init : function(){
			$('.menu li').on('click',nav);
		}
	}
	
}(jQuery));

$(document).ready(function(){
	
	Page.init();
	
});