import React from 'react';

const About = ({match}) => {
	
	return (
		<h1>{match.params.namea} 소개</h1>
	) 
}

export default About;