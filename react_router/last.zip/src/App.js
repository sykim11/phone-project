import React, { Component } from 'react';
import './App.css';

// 컴포넌트
import Home from './Home';
import About from './About';
import Header from './Header';

// 모듈
import { BrowserRouter as Router , Route } from 'react-router-dom';

/*
	
	react-router-dom 을 쓰면
	컴포넌트 실행시킬때 마다 ( 3가지 정보를 들고 다닌다. )
	match , history , pathname
	
*/

class App extends Component {
  render() {
    return (
    	<Router>
			<div>
				<Header />
				<Route exact path="/" component={Home} />
				<Route path="/about/:namea" component={About} />
			</div>
		</Router>
    );
  }
}

export default App;








