import React from 'react';

const About = ({match}) => {

	return (
		<div>
			<h1>{match.params.namea} 소개페이지 입니다.</h1>
		</div>
	)
}

export default About;
