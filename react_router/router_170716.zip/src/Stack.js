import React from 'react';
import { Route, Link } from 'react-router-dom';

const StackContent = ({match}) => {
	return(
			<div className="depths_content">
				<h2>{match.params.title}</h2>
				<div className="desc">{match.params.title} 소개 및 설명</div>
			</div>
	)
}

const Stack = () => {

	return (
		<div className="list">
			<h1>기술 페이지입니다.</h1>
			<div className="depths_menu">
				<Link to="/stack/react" className="stack">react</Link>
				<Link to="/stack/angular" className="stack">angular</Link>
				<Link to="/stack/vue" className="stack">vue</Link>
				<Route path="/stack/:title" component={StackContent} />
			</div>
		</div>
	)
}

export default Stack;
