import React from 'react';

const Home = ({history}) => {
	
	return (
		<div>
			<h1>홈</h1>
			<button onClick={()=>{history.push('/about')}}>소개페이지로 이동</button>
		</div>
	)
}

export default Home;