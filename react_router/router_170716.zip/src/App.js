import React, { Component } from 'react';
import './App.css';

// 컴포넌트
import Home from './Home';
import Header from './Header';
import About from './About';
import Stack from './Stack';
import Mypage from './Mypage';
import Skin from './Skin';

// 모듈
import { BrowserRouter as Router , Route } from 'react-router-dom';

/*

	react-router-dom 을 쓰면
	컴포넌트 실행시킬때 마다 ( 3가지 정보를 들고 다닌다. )
	match , history , pathname

*/

class App extends Component {
  render() {
    return (
    	<Router>
  			<div>
  				<Header />
  				<Route exact path="/" component={Home} />
  				<Route path="/about/:namea" component={About} />
          <Route path="/stack/" component={Stack} />
          <Route path="/mypage" component={Mypage} />
          <Route path="/skin" component={Skin} />
  			</div>
      </Router>
    );
  }
}

export default App;
