import React from 'react';
import { Redirect } from 'react-router-dom';
import './Header.css';

const logged = true;
// const logged = false;

const Mypage = () => {

	return (
		<div className="list">
			{
				!logged && <Redirect to="/" />
			}
			<h1>logged가 true인 상태, 마이페이지로 들어왔습니다.</h1>
		</div>
	)
}

export default Mypage;
