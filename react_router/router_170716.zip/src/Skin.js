import React from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import Card from './Components/Card';

const Skin = () => {

	const style = {
		width : '1100px',
		margin : '0 auto'
	}

	return (
		<div className="list">
			<h1>React Material Design<a href="http://www.material-ui.com/#/get-started/usage" target="_blank">바로가기</a></h1>
			<div style={style}>
				<MuiThemeProvider>
					<Card />
				</MuiThemeProvider>
			</div>

		</div>
	)
}

export default Skin;
