import React from 'react';
import './Container.css';

const Intro = ({match}) => {
  return (

        <div className="content_box">
          <p className="title">{match.params.name}소개페이지</p>
        </div>
  )
}


export default Intro;
