import React from 'react';
import './Container.css';

class Container extends React.Component{
  constructor(props){
    super(props)
  }

  render(){

    return (

          <div className="Container">
            <div className="inner">
              {this.props.content}
            </div>
          </div>

    )
  }
}

export default Container;
