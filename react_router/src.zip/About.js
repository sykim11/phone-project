import React from 'react';
// import './Container.css';


class About extends React.Component{

  render(){

    return (

          <div className="content_box">
            <p className="title">소개페이지--</p>
          </div>
    )
  }
}

export default About;
