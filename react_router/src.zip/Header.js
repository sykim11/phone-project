import React from 'react';
import './Header.css';
import Home from './Home.js';
import Intro from './Intro.js';
import { NavLink } from 'react-router-dom';


import { BrowserRouter as Router , Route } from 'react-router-dom';
class Header extends React.Component{
  constructor(props){
    super(props);
    this.tech = this.tech.bind(this);
    this.Intro = this.Intro.bind(this);
    // this.page = this.page.bind(this);
  }
  Home(){
    this.props.HomeFunc();
  }
  Intro(){
    this.props.IntroFunc();
  }
  tech(){
    this.props.techFunc();
  }
  // page(){
  //   this.props.pageFunc();
  // }

  render(){

    return (

          <div className="header">
            <ul>
              <li><NavLink exact to="/" component={Home} activeClassName="active">홈</NavLink></li>
              <li><NavLink to="/About/:name" component={Intro} activeClassName="active">소개</NavLink></li>
              <li><NavLink to="/tech" onClick={this.tech} activeClassName="active">기술</NavLink></li>
              <li><a href="javascript:void(0)">페이지</a></li>
              <li><a href="#">로그인</a></li>
              <li><a href="#">검색</a></li>
            </ul>
          </div>

    )
  }
}

export default Header;
