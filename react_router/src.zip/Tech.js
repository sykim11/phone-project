import React from 'react';


class Tech extends React.Component{

  render(){

    return (

          <div className="content_box">
            <p className="title">기술페이지</p>
          </div>
    )
  }
}

export default Tech;
