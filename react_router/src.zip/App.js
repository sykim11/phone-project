import React, { Component } from 'react';
import './App.css';
import Header from './Header.js';
import Home from './Home.js';
import About from './About.js';
import Container from './Container.js';
import Intro from './Intro.js';
import Tech from './Tech.js';

//Module
import { BrowserRouter as Router , Route } from 'react-router-dom';
/*
  react-router-dom 을 쓰면
  컴포넌트 실핼시킬때 마다 (3가지 정보를 들고 다닌다.)
  match, history, pathname
*/
class App extends Component {
  constructor(props){
    super(props)
    this.setIntro = this.setIntro.bind(this);
    this.setTech = this.setTech.bind(this);
    this.state = {
      data : 'this home'
    }
  }
  setHome(){
    this.setState({
      data : <Home />
    })
  }
  setIntro(){
    this.setState({
      data : <Intro />
    })
  }
  setTech(){
    this.setState({
      data : <Tech />
    })
  }
  render() {
    return (
      <Router>
        <div className="wrap">
          <Header
            HomeFunc={this.setHome}
            IntroFunc={this.setIntro}
            techFunc={this.setTech}
          />
          <Route exact path="/" component={Home} />
          <Route exact path="/About/:name" component={About} />
          <Container
            content={this.state.data}
           />
        </div>
      </Router>
    );
  }
}

export default App;
